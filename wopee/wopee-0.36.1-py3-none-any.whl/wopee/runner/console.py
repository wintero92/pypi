"Module: wopee console runner."

import sys

from pydantic import ValidationError

from wopee.wopee import BotMap
from wopee.config.bot_config import load_yaml_config, BotConfig


def run():
    """Default runner for wopee."""

    n_argv = len(sys.argv) - 1
    if n_argv == 1:
        config = load_yaml_config(sys.argv[1])
    else:
        try:
            config = BotConfig()
        except ValidationError as error:
            print(error.json())
            sys.exit(1)
    bot_map = BotMap(config)
    bot_map.run()
