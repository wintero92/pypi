"Base Wopee class containing the main loop."

import logging
import logging.config
from typing import List

import sys

from faker import Faker

from visual_regression_tracker import IgnoreArea

import wopee
from wopee.browser.playwright import Playwright
from wopee.config.logging_config import LOGGING_CONFIG
from wopee.config.bot_config import BotConfig
from wopee.database.neo4jdriver import Neo4jDriver
from wopee.datatypes.helper import encode_base64
from wopee.tracker.vrt import Vrt

logging.config.dictConfig(LOGGING_CONFIG)
logger = logging.getLogger(__name__)


class BotMap:
    "BotMap class"

    def __init__(self, config: BotConfig):
        logger.info("Welcome to autonomous testing!")
        logger.info("Wopee (version %s) starting.", wopee.__version__)
        self.config = config
        self.graph = Neo4jDriver(self.config)
        self.tracker = Vrt(self.config)
        self.browser = Playwright(self.config)
        self.start()
        self.visited = []
        logger.debug("Config: %s", self.config)

    def stop(self):
        "Stop modules."
        self.tracker.stop()
        self.browser.stop()
        self.graph.stop()

    def start(self):
        "Start modules."
        self.tracker.start()
        self.browser.start()
        self.graph.start()

    def run(self):
        "Main runner."
        self.graph.create_project()
        suite_id = self.graph.create_suite()

        if self.config.run_scenarios:
            for target_node in self.config.run_scenarios:
                if not self.graph.find_by_id(target_node):
                    logger.critical(
                        "Screen with id: %s does not exists under running project.",
                        target_node,
                    )
                    sys.exit(1)
            self._run_scenarios(suite_id)
        else:
            self._random(suite_id)

        self.stop()

    def _run_scenarios(self, suite_id: str):
        starting_screen = self.graph.get_starting_screen()
        for target_node in self.config.run_scenarios:
            logger.info("Scenario with target: %s", target_node)
            scenario_id = self.graph.create_scenario(suite_id)
            starting_instance_id = self.graph.create_starting_screen_instance(
                scenario_id, starting_screen["SCREEN_ID"]
            )
            result = self.browser.start_context()
            if not result:
                break
            height = self.browser.scroll_down()
            if self.config.learning_mode:
                acceptable_states = self.browser.collect_all_acceptable_states()
                logger.debug("Acceptable states: %s", acceptable_states)
                self.graph.update_graph(acceptable_states, starting_screen["SCREEN_ID"])
            image64 = self.browser.screenshot(height, "//div[1]")
            page_title = self.browser.page_title()
            url = self.browser.url()

            try:
                self.graph.add_property(
                    starting_screen["SCREEN_ID"],
                    "pageTitle",
                    page_title,
                )
                self.graph.add_property(
                    starting_screen["SCREEN_ID"],
                    "url",
                    url,
                )
            except:  # pylint: disable=bare-except
                logger.debug("Page title or url update unsuccessful")

            ignore_areas = self._get_ignore_areas(starting_screen["SCREEN_ID"])
            logger.debug("Using ignore_areas %s", ignore_areas)
            vrt_responce = self.tracker.screenshot(
                starting_screen["SCREEN_ID"], image64, ignore_areas=ignore_areas
            )
            self.graph.add_property(
                starting_instance_id,
                "vrt_status",
                vrt_responce.testRunResponse.status.value,
            )
            self.graph.add_property(
                starting_instance_id, "vt_url", vrt_responce.testRunResponse.url
            )
            steps = self.graph.get_random_path(
                starting_screen["SCREEN_ID"], target_node
            )
            logger.debug("Scenario will go through nodes: %s", steps)
            self._run_scenario(scenario_id, steps)
            self.browser.close_context(scenario_id)

    def _random(self, suite_id: str):
        starting_screen = self.graph.get_starting_screen()
        for ith_test in range(0, self.config.number_of_scenarios):
            logger.info("Scenario: %s", str(ith_test + 1))
            scenario_id = self.graph.create_scenario(suite_id)
            starting_instance_id = self.graph.create_starting_screen_instance(
                scenario_id, starting_screen["SCREEN_ID"]
            )
            result = self.browser.start_context()
            if not result:
                break
            height = self.browser.scroll_down()
            if (
                self.config.experimental_login_action
                and self.browser.collect_acceptable_logins()
            ):
                login_user = self.config.experimental_login_action["login_user"]
                login_user_locator = self.config.experimental_login_action[
                    "login_user_locator"
                ]
                login_password = self.config.experimental_login_action["login_password"]
                login_password_locator = self.config.experimental_login_action[
                    "login_password_locator"
                ]
                login_button = self.config.experimental_login_action["login_button"]
                login_ok = None
                if "login_ok" in self.config.experimental_login_action.keys():
                    login_ok = self.config.experimental_login_action["login_ok"]
                try:
                    self.browser.fill(login_user_locator, login_user)
                    self.browser.fill(login_password_locator, login_password)
                    self.browser.click(login_button)
                    if login_ok:
                        self.browser.wait_for_element(login_ok)
                    self.browser.accept_cookies()
                except:  # pylint: disable=bare-except
                    logger.error("Login failed.")
                    break
            if self.config.learning_mode:
                acceptable_states = self.browser.collect_all_acceptable_states()
                logger.debug("Acceptable states: %s", acceptable_states)
                self.graph.update_graph(acceptable_states, starting_screen["SCREEN_ID"])
            image64 = self.browser.screenshot(height, "//div[1]")
            page_title = self.browser.page_title()
            url = self.browser.url()

            try:
                self.graph.add_property(
                    starting_instance_id,
                    "pageTitle",
                    page_title,
                )
                self.graph.add_property(
                    starting_instance_id,
                    "url",
                    url,
                )
            except:  # pylint: disable=bare-except
                logger.debug("Page title or url update unsuccessful")

            ignore_areas = self._get_ignore_areas(starting_screen["SCREEN_ID"])
            logger.debug("Using ignore_areas %s", ignore_areas)
            vrt_responce = self.tracker.screenshot(
                starting_screen["SCREEN_ID"], image64, ignore_areas=ignore_areas
            )
            self.graph.add_property(
                starting_instance_id,
                "vrt_status",
                vrt_responce.testRunResponse.status.value,
            )
            self.graph.add_property(
                starting_instance_id, "vt_url", vrt_responce.testRunResponse.url
            )
            steps = None
            if self.config.cover_mode:
                steps = self.graph.get_cover_path(self.config.neo4j_project_name)
            else:
                target = self.graph.get_random_screen()
                steps = self.graph.get_random_path(starting_screen["SCREEN_ID"], target)
            logger.debug("Scenario will go through nodes: %s", steps)
            self._run_scenario(scenario_id, steps)
            self.browser.close_context(scenario_id)

    def _run_scenario(self, scenario_id: str, steps: List):
        previous_step = scenario_id
        for step in steps:
            action = step["action"]
            screen = step["screen"]
            if screen["id"] in self.config.ignored_nodes:
                logger.debug(
                    "Encounter ignored position %s. Ending scenario.", screen["id"]
                )
                break
            step_id = self.graph.create_step(previous_step)
            if action["type"] == "Click":
                locator = action["locator"]
                instance_id = self.graph.create_click_instance(
                    step_id, action["id"], encode_base64(locator)
                )
                if self.browser.check_if_ignored(locator):
                    self.graph.add_label(instance_id, "Skipped")
                    self.graph.add_property(step_id, "status", "Skipped")
                    break
                result = self.browser.click(locator)
                if not result:
                    self.graph.add_label(instance_id, "Failed")
                    self.graph.add_property(step_id, "status", "Failed")
                    break
                self.graph.add_label(instance_id, "Passed")
                self.graph.add_property(step_id, "status", "Passed")

                if not self.browser.check_domain():
                    self.graph.add_label(screen["id"], "External")
                    self.graph.add_property(step_id, "status", "External")
                    break
                try:
                    curr_height = self.browser.scroll_down()
                except:  # pylint: disable=bare-except
                    logger.exception("Ops", exc_info=True)
                    continue
            if action["type"] == "Fill":
                filament = self._get_filament()
                locator = action["locator"]
                self.graph.create_fill_instance(
                    step_id,
                    action["id"],
                    encode_base64(locator),
                    encode_base64(filament),
                )
                try:
                    filament = self._get_filament()
                    self.browser.fill(action["locator"], filament)
                    self.browser.scroll_down()
                except:  # pylint: disable=bare-except
                    logger.exception("Ops", exc_info=True)

            screen_instance_id = self.graph.create_screen_instance(
                step_id, screen["id"]
            )

            image64 = self.browser.screenshot(curr_height, action["locator"])
            page_title = self.browser.page_title()
            url = self.browser.url()

            try:
                self.graph.add_property(
                    screen_instance_id,
                    "pageTitle",
                    page_title,
                )
                self.graph.add_property(
                    screen_instance_id,
                    "url",
                    url,
                )
            except:  # pylint: disable=bare-except
                logger.debug("Page title or url update unsuccessful")

            try:
                if self.config.learning_mode:
                    acceptable_states = self.browser.collect_all_acceptable_states()
                    logger.debug("Acceptable states: %s", screen["id"])
                    self.graph.update_graph(acceptable_states, screen["id"])
                    acceptable_states = self.browser.collect_acceptable_inputs()
                    logger.debug("Acceptable inputs: %s", screen["id"])
                    self.graph.update_graph_fill(acceptable_states, screen["id"])
            except:  # pylint: disable=bare-except
                logger.debug("Graph update unsuccessful")

            try:
                if screen["id"] not in self.config.ignored_nodes_visual_diff:
                    ignore_areas = self._get_ignore_areas(screen["id"])
                    logger.debug("Using ignore_areas %s", ignore_areas)
                    vrt_responce = self.tracker.screenshot(
                        screen["id"], image64, ignore_areas=ignore_areas
                    )
                    self.graph.add_property(
                        screen_instance_id,
                        "vrt_status",
                        vrt_responce.testRunResponse.status.value,
                    )
                    self.graph.add_property(
                        screen_instance_id, "vrt_url", vrt_responce.testRunResponse.url
                    )
                self.visited.append(screen["id"])
            except:  # pylint: disable=bare-except
                logger.exception("Ops", exc_info=True)
            previous_step = step_id

    def _get_ignore_areas(self, position):
        ignore_areas = self._get_ignore_areas_from_coordinates(position)
        ignore_areas.extend(self._get_ignore_areas_from_locators())
        return ignore_areas

    def _get_ignore_areas_from_coordinates(self, position):
        ignore_areas = self._get_ignore_areas_for_position("all")
        ignore_areas.extend(self._get_ignore_areas_for_position(position))
        return ignore_areas

    def _get_ignore_areas_for_position(self, position):
        ignore_areas = []
        if position in self.config.ignored_areas_by_coordinates.keys():
            areas = self.config.ignored_areas_by_coordinates[position]
            for area in areas:
                ignore_areas.append(IgnoreArea(area[0], area[1], area[2], area[3]))
        return ignore_areas

    def _get_ignore_areas_from_locators(self):
        ignore_areas = []
        for locator in self.config.ignored_areas_by_locator:
            elements = self.browser.page.locator(locator)
            n_elements = elements.count()
            for i in range(n_elements):
                element = elements.nth(i)
                bounding_box = element.bounding_box()
                if bounding_box is not None:
                    ignore_areas.append(
                        IgnoreArea(
                            bounding_box["x"],
                            bounding_box["y"],
                            bounding_box["width"],
                            bounding_box["height"],
                        )
                    )
        return ignore_areas

    def _get_filament(self):
        if self.config.experimental_fill_form_faker:
            fake = Faker()
            return fake.job()
        return self.config.experimental_fill_form_string
