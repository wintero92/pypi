"""
Configuration orchestraion for the BotMap.
"""

# pylint: disable=no-self-argument
# pylint: disable=too-few-public-methods
# pylint: disable=missing-function-docstring

import logging
import sys
from typing import List, Union
from uuid import uuid1

import yaml
from pydantic import BaseSettings, Field, ValidationError, validator

logger = logging.getLogger(__name__)


class BotConfig(BaseSettings):
    """
    Configuration for the bot-mvp.
    """

    class Config:
        """Overload config options."""

        extra = "allow"

    url: str = Field(..., env="URL")

    neo4j_project_name: str = Field(..., env="NEO4j_PROJECT_NAME")
    neo4j_scheme: str = Field(default="bolt", env="NEO4j_SCHEME")
    neo4j_host_name: str = Field(..., env="NEO4J_HOST_NAME")
    neo4j_port: int = Field(..., env="NEO4J_PORT")
    neo4j_user: str = Field(default="neo4j", env="NEO4J_USER")
    neo4j_password: str = Field(..., env="NEO4J_PASSWORD")

    vrt_project_name: str = Field(..., env="VRT_PROJECT_NAME")
    vrt_api_key: str = Field(..., env="VRT_API_KEY")
    vrt_api_url: str = Field(..., env="VRT_API_URL")
    vrt_branch_name: str = Field(default="master", env="VRT_BRANCH_NAME")
    vrt_ci_build_id: str = Field(default=str(uuid1()), env="VRT_CI_BUILD_ID")
    vrt_diff_tollerance: float = Field(default=2.0, env="VRT_DIFF_TOLLERANCE")

    run_scenarios: List[str] = Field(default=[], env="RUN_SCENARIOS")
    number_of_scenarios: int = Field(default=10, env="NUMBER_OF_SCENARIOS")
    tags: List[str] = Field(default=["a", "button"], env="tags")

    cookies_selector: Union[str, List[str]] = None
    headless: bool = Field(default=True, env="HEADLESS")
    ignore_https_errors: bool = Field(default=True, env="IGNORE_HTTPS_ERRORS")
    time_out: int = Field(default=1000, env="TIME_OUT")

    ignored_areas_by_locator: List[str] = Field(
        default=[], env="IGNORED_AREAS_BY_LOCATOR"
    )
    ignored_areas_by_coordinates: dict = Field(
        default={}, env="IGNORED_AREAS_BY_COORDINATES"
    )
    experimental_fill_form: bool = Field(default=False, env="EXPERIMENTAL_FILL_FORM")
    experimental_fill_form_string: str = Field(
        default="wopee", env="EXPERIMENTAL_FILL_FORM_STRING"
    )
    experimental_fill_form_faker: bool = Field(
        default=True, env="EXPERIMENTAL_FILL_FORM_FAKER"
    )

    learning_mode: bool = Field(default=True, env="LEARNING_MODE")
    cover_mode: bool = Field(default=False, env="COVER_MODE")

    ignored_nodes_visual_diff: List[str] = Field(
        default=[], env="IGNORED_NODES_VISUAL_DIFF"
    )
    ignored_nodes: List[str] = Field(default=[], env="IGNORED_NODES")

    experimental_ignore_visited_nodes: bool = Field(
        default=False, env="EXPERIMENTAL_IGNORE_VISITED_NODES"
    )

    experimental_login_action: dict = Field(
        default=None, env="EXPERIMENTAL_LOGIN_ACTION"
    )

    save_trace: bool = Field(default=False, env="SAVE_TRACE")

    save_video: bool = Field(default=False, env="SAVE_VIDEO")

    ignored_locators: List[str] = Field(default=[], env="IGNORED_LOCATORS")

    allowed_urls: List[str] = Field(default=[], env="ALLOWED_URLS")

    navigation_timeout: float = Field(default=30000, env="NAVIGATION_TIMEOUT")

    after_load_screenshot_timeout: float = Field(default=0, env="AFTER_LOAD_SCREENSHOT_TIMEOUT")

    @validator("cover_mode")
    def modes(cls, value, *, values):
        if value:
            if value and values["learning_mode"]:
                values["learning_mode"] = False
        return value

    @validator("experimental_login_action")
    def experimental_login_action_check(cls, field):
        if field is None:
            return field
        should_haves = [
            "trigger",
            "login_user",
            "login_user_locator",
            "login_password",
            "login_password_locator",
            "login_button",
        ]
        optional_haves = ["login_ok"]
        for should_have in should_haves:
            if not should_have in field.keys():
                raise ValueError(f"Must have keys {should_have}, optional keys {optional_haves}")
        return field

    @validator("number_of_scenarios")
    def max_number_of_scenarios(value):
        if value > 500:
            raise ValueError("Max: 500")
        return value


def load_yaml_config(config_file_path: str) -> BotConfig:
    """
    Loads the configuration from a yaml file.
    """
    with open(config_file_path, "r", encoding="utf-8") as file:
        config = yaml.safe_load(file)
    try:
        bot_config = BotConfig(**config)
    except ValidationError as error:
        print(error.json())
        sys.exit(1)

    if bot_config.cover_mode and bot_config.learning_mode:
        logger.warning("Learning mode disabled, continue with cover mode")
        bot_config.cover_mode = False

    return bot_config
