"Log configuration for the module."

# pylint: disable=line-too-long
# pylint: disable=too-few-public-methods

import logging


class OnlyInfoAndCritical(logging.Filter):
    "Class for logging filter to log only info and critical level messages."

    def filter(self, record):
        "Logging filter to log only info and critical level messages."
        return record.levelno in (logging.INFO, logging.CRITICAL)


LOGGING_CONFIG = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "verbose": {
            "format": "[%(asctime)s.%(msecs)03d][%(levelname)s][%(name)s]: %(message)s",
            "datefmt": "%Y.%m.%d-%H:%M:%S",
        },
        "stdout": {
            "format": "[%(asctime)s.%(msecs)03d][%(levelname)s]: %(message)s",
            "datefmt": "%Y.%m.%d-%H:%M:%S",
        },
    },
    "filters": {"only_info_and_critical": {"()": OnlyInfoAndCritical}},
    "handlers": {
        "logfile": {
            "class": "logging.FileHandler",
            "filename": "wopee.log",
            "encoding": "utf-8",
            "mode": "w",
            "formatter": "verbose",
            "level": "DEBUG",
        },
        "logfile_error": {
            "class": "logging.FileHandler",
            "filename": "wopee.error.log",
            "encoding": "utf-8",
            "mode": "w",
            "formatter": "verbose",
            "level": "ERROR",
        },
        "stdout": {
            "class": "logging.StreamHandler",
            "formatter": "stdout",
            "level": "INFO",
            "filters": ["only_info_and_critical"],
        },
    },
    "loggers": {
        "wopee": {
            "level": "DEBUG",
            "handlers": ["logfile", "logfile_error", "stdout"],
        },
    },
    "root": {
        "level": "INFO",
        "handlers": [
            "logfile_error",
        ],
    },
}
