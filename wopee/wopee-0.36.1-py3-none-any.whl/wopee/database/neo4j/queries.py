"Queries generator for Neo4jDB driver."


import logging
import random

from enum import Enum
from typing import Dict
from neo4j import Neo4jDriver

from wopee.datatypes.helper import decode_base64

logger = logging.getLogger(__name__)


class Node(Enum):
    "Types of Node(s)"
    CLICK = "Click"
    FILL = "Fill"
    LOGIN = "Login"
    SCREEN = "Screen"


class QueryTemplates:
    "Teplates for specific queries"

    @staticmethod
    def find_action(
        screen_id: str,
        action_type: Node,
        key: str,
        key_value: str,
        driver: Neo4jDriver,
    ):
        "Generic method to find if Action already exists"
        entries = [
            f'MATCH (screen:Screen {{id: "{screen_id}"}})',
            "-[:DO_A]->",
            f'(action:{action_type.value} {{{key}: "{key_value}"}})',
            f"RETURN action.{key} as KEY",
        ]
        query = " ".join(entries)
        logger.debug("Neo4j query: %s", query)
        session = driver.session()
        records = session.run(query)
        records = [record["KEY"] for record in records]
        session.close()
        if key_value in records:
            logger.debug("Action founded")
            return True
        return False

    @staticmethod
    def create_action(
        start_id: str,
        action_id: str,
        action_type: Node,
        screen_id: str,
        driver: Neo4jDriver,
    ):
        "Template query for generic Action"
        entries = [
            f'MATCH (start:Screen {{id: "{start_id}"}})',
            "CREATE (start)",
            "-[:DO_A {createdAt: datetime()}]->",
            f'(action:{action_type.value} {{id: "{action_id}", name: "{action_id}", createdAt: datetime()}})',
            "-[:GOES_TO {createdAt: datetime()}]->",
            f'(screen:Screen {{id: "{screen_id}", name: "{screen_id}", createdAt: datetime()}})',
        ]
        query = " ".join(entries)
        logger.debug("Neo4j query: %s", query)
        session = driver.session()
        session.run(query)
        session.close()

    @staticmethod
    def add_property(node_id: str, key: str, key_value: str, driver: Neo4jDriver):
        "Add key and value to given node"
        entries = [
            f'MATCH (object {{id: "{node_id}"}})',
            f'SET object.{key} = "{key_value}"',
        ]
        query = " ".join(entries)
        logger.debug("Neo4j query: %s", query)
        session = driver.session()
        session.run(query)
        session.close()

    @staticmethod
    def add_label(node_id: str, label: str, driver: Neo4jDriver):
        "Add label to given node"
        entries = [
            f'MATCH (object {{id: "{node_id}"}})',
            f"SET object:{label}",
        ]
        query = " ".join(entries)
        logger.debug("Neo4j query: %s", query)
        session = driver.session()
        session.run(query)
        session.close()

    @staticmethod
    def create_instance(
        step_id: str,
        action_id: str,
        action_type: Node,
        instance_id: str,
        driver: Neo4jDriver,
    ):
        "Template query for generic Instance"
        entries = [
            f'MATCH (step:Step {{id: "{step_id}"}})',
            f'MATCH (action:{action_type.value} {{id: "{action_id}"}})',
            "CREATE (step)-[:DO_A {createdAt: datetime()}]->",
            f'(instance:{action_type.value}Instance {{id: "{instance_id}",',
            f'name: "{instance_id}", createdAt: datetime()}})',
            "-[:INSTANCE_OF {createdAt: datetime()}]->(action)",
        ]
        query = " ".join(entries)
        logger.debug("Neo4j query: %s", query)
        session = driver.session()
        session.run(query)
        session.close()


class ActionQuery:
    "Cypher queries for Action(s)"

    @staticmethod
    def create_click(data: Dict, driver: Neo4jDriver):
        "Create Click action query"
        action = Node.CLICK
        try:
            start_id = data["start_id"]
            click_id = data["click_id"]
            locator = data["locator"]
            screen_id = data["screen_id"]
        except KeyError:
            logger.exception(exc_info=True)
        if not QueryTemplates.find_action(start_id, action, "locator", locator, driver):
            QueryTemplates.create_action(start_id, click_id, action, screen_id, driver)
            QueryTemplates.add_property(click_id, "locator", locator, driver)

    @staticmethod
    def create_fill(data: Dict, driver: Neo4jDriver):
        "Create Fill action query"
        action = Node.FILL
        try:
            start_id = data["start_id"]
            fill_id = data["fill_id"]
            locator = data["locator"]
            screen_id = data["screen_id"]
        except KeyError:
            logger.exception(exc_info=True)
        if not QueryTemplates.find_action(start_id, action, "locator", locator, driver):
            QueryTemplates.create_action(start_id, fill_id, action, screen_id, driver)
            QueryTemplates.add_property(fill_id, "locator", locator, driver)

    @staticmethod
    def create_login(data: Dict, driver: Neo4jDriver):
        "Create Login action query"
        action = Node.LOGIN
        try:
            start_id = data["start_id"]
            login_id = data["login_id"]
            trigger = data["trigger"]
            login_user_locator = data["login_user_locator"]
            login_password_locator = data["login_password_locator"]
            login_button = data["login_button"]
            screen_id = data["screen_id"]
        except KeyError:
            logger.exception(exc_info=True)
        if not QueryTemplates.find_action(start_id, action, "trigger", trigger, driver):
            QueryTemplates.create_action(start_id, login_id, action, screen_id, driver)
            QueryTemplates.add_property(login_id, "trigger", trigger, driver)
            QueryTemplates.add_property(
                login_id, "login_user_locator", login_user_locator, driver
            )
            QueryTemplates.add_property(
                login_id, "login_password_locator", login_password_locator, driver
            )
            QueryTemplates.add_property(login_id, "login_button", login_button, driver)


class InstanceQuery:
    "Cypher queries for Instance(s)"

    @staticmethod
    def create_screen_instance(data: Dict, driver: Neo4jDriver):
        "Create ScreenInstance query"
        try:
            step_id = data["step_id"]
            instance_id = data["instance_id"]
            screen_id = data["screen_id"]
        except KeyError:
            logger.exception(exc_info=True)

        entries = [
            f'MATCH (step:Step {{id: "{step_id}"}})',
            f'MATCH (screen:Screen {{id: "{screen_id}"}})',
            "CREATE (step)-[:GOES_TO {createdAt: datetime()}]->",
            f'(instance:ScreenInstance {{id: "{instance_id}",',
            f'name: "{instance_id}", createdAt: datetime()}})',
            "-[:INSTANCE_OF {createdAt: datetime()}]->(screen)",
        ]
        query = " ".join(entries)
        logger.debug("Neo4j query: %s", query)
        session = driver.session()
        session.run(query)
        session.close()

    @staticmethod
    def create_click_instance(
        data: Dict,
        driver: Neo4jDriver,
    ):
        "Create ClickInstance query"
        action = Node.CLICK
        try:
            step_id = data["step_id"]
            instance_id = data["instance_id"]
            click_id = data["click_id"]
            locator = data["locator"]
        except KeyError:
            logger.exception("Ups", exc_info=True)
        QueryTemplates.create_instance(step_id, click_id, action, instance_id, driver)
        QueryTemplates.add_property(instance_id, "locator", locator, driver)

    @staticmethod
    def create_fill_instance(
        data: Dict,
        driver: Neo4jDriver,
    ):
        "Create FillInstance query"
        action = Node.FILL
        try:
            step_id = data["step_id"]
            instance_id = data["instance_id"]
            fill_id = data["click_id"]
            locator = data["locator"]
            filament = data["filament"]
        except KeyError:
            logger.exception(exc_info=True)
        QueryTemplates.create_instance(step_id, fill_id, action, instance_id, driver)
        QueryTemplates.add_property(instance_id, "locator", locator, driver)
        QueryTemplates.add_property(instance_id, "filament", filament, driver)

    @staticmethod
    def create_login_instance(
        data: Dict,
        driver: Neo4jDriver,
    ):
        "Create LoginInstance query"
        action = Node.LOGIN
        try:
            step_id = data["step_id"]
            instance_id = data["instance_id"]
            login_id = data["click_id"]
            login_user = data["login_user"]
            login_password = data["login_password"]
        except KeyError:
            logger.exception(exc_info=True)
        QueryTemplates.create_instance(step_id, login_id, action, instance_id, driver)
        QueryTemplates.add_property(instance_id, "login_user", login_user, driver)
        QueryTemplates.add_property(
            instance_id, "login_password", login_password, driver
        )


class TestingQuery:
    "Cypher queries for Testing infrastructure"

    @staticmethod
    def create_suite(project_id: str, suite_id: str, driver: Neo4jDriver):
        "Create Suite"
        entries = [
            f'MATCH (project:Project {{id: "{project_id}"}})',
            "CREATE (project)",
            "-[:OWNS {createdAt: datetime()}]->",
            f'(suite:Suite {{id: "{suite_id}", name : "{suite_id}", createdAt: datetime()}})',
        ]
        query = " ".join(entries)
        logger.debug("Neo4j query: %s", query)
        session = driver.session()
        session.run(query)
        session.close()
        logger.debug("New Suite %s created", suite_id)

    @staticmethod
    def create_scenario(suite_id: str, scenario_id: str, driver: Neo4jDriver):
        "Create Scenario"
        entries = [
            f'MATCH (suite:Suite {{id: "{suite_id}"}})',
            "CREATE (suite)",
            "-[:OWNS {createdAt: datetime()}]->",
            f'(scenario:Scenario {{id: "{scenario_id}", name : "{scenario_id}", createdAt: datetime()}})',
        ]
        query = " ".join(entries)
        logger.debug("Neo4j query: %s", query)
        session = driver.session()
        session.run(query)
        session.close()
        logger.debug("New Scenario %s created", scenario_id)

    @staticmethod
    def create_step(start_id: str, step_id: str, driver: Neo4jDriver):
        "Create step"
        entries = [
            f'MATCH (start {{id: "{start_id}"}})',
            "CREATE (start)",
            "-[:RUN {createdAt: datetime()}]->",
            f'(step:Step {{id: "{step_id}", name : "{step_id}", createdAt: datetime()}})',
        ]
        query = " ".join(entries)
        logger.debug("Neo4j query: %s", query)
        session = driver.session()
        session.run(query)
        session.close()
        logger.debug("New Step %s created", step_id)


class OneTimeQuery:
    "Cypher queries to be run only once"

    @staticmethod
    def is_project_existing(project_id: str, driver: Neo4jDriver) -> bool:
        "Check if project of given id alrady exists"
        entries = ["MATCH (project:Project) RETURN project.id AS ID"]
        query = " ".join(entries)
        logger.debug("Neo4j query: %s", query)
        session = driver.session()
        records = session.run(query)
        existing_projects = [record["ID"] for record in records]
        session.close()
        if project_id in existing_projects:
            logger.debug("Project %s exists", project_id)
            return True
        logger.debug("Project %s does not exits", project_id)
        return False

    @staticmethod
    def create_project(project_id: str, driver: Neo4jDriver) -> None:
        "Create project with given id"
        entries = [
            f'CREATE (n:Project{{id: "{project_id}", name: "{project_id}", createdAt: datetime()}})'
        ]
        query = " ".join(entries)
        logger.debug("Neo4j query: %s", query)
        session = driver.session()
        session.run(query)
        session.close()
        logger.debug("New Project %s created", project_id)

    @staticmethod
    def create_starting_screen(
        project_id: str,
        starting_screen_id: str,
        screen_id: str,
        url: str,
        driver: Neo4jDriver,
    ):
        "Create starting screen associated with given project id"
        entries = [
            f'MATCH (project:Project {{id: "{project_id}"}})',
            "CREATE (project)",
            "-[:OWNS {createdAt: datetime()}]->",
            f'(startingScreen:StartingScreen{{id: "{starting_screen_id}",',
            f'name: "{url}", url: "{url}", createdAt: datetime()}})',
        ]
        query = " ".join(entries)
        logger.debug("Neo4j query: %s", query)
        session = driver.session()
        session.run(query)
        session.close()
        entries = [
            f'MATCH (startingScreen:StartingScreen {{id: "{starting_screen_id}"}})',
            "CREATE (startingScreen)",
            "<-[:IS_A {createdAt: datetime()}]-",
            f'(screen:Screen {{id: "{screen_id}", name: "{screen_id}", createdAt: datetime()}})',
        ]
        query = " ".join(entries)
        logger.debug("Neo4j query: %s", query)
        session = driver.session()
        session.run(query)
        session.close()
        logger.debug("New starting screen: url: %s created", url)

    @staticmethod
    def get_starting_screen(project_id: str, driver: Neo4jDriver):
        "Get starting screen data"
        entries = [
            f'MATCH (project:Project {{id: "{project_id}"}})',
            "-[:OWNS]->",
            "(startingscreen:StartingScreen)",
            "<-[:IS_A]-",
            "(screen)",
            "RETURN screen.id as SCREEN_ID, startingscreen.id as STARTINGSCREEN_ID, startingscreen.url as URL",
        ]
        query = " ".join(entries)
        logger.debug("Neo4j query: %s", query)
        session = driver.session()
        records = session.run(query)
        record = records.single()
        data = {
            "STARTINGSCREEN_ID": record["STARTINGSCREEN_ID"],
            "SCREEN_ID": record["SCREEN_ID"],
            "URL": record["URL"],
        }
        session.close()
        return data


class TargetQuery:
    "Cypher queries generating targets"

    @staticmethod
    def get_random_screen(project_name: str, driver: Neo4jDriver):
        "Get random screen"
        starting_screen = OneTimeQuery.get_starting_screen(project_name, driver)
        entries = [
            f'MATCH (screen {{id: "{starting_screen["SCREEN_ID"]}"}})',
            "MATCH (screen)",
            "-[:GOES_TO|DO_A*0..]-",
            "(target:Screen)",
            "WITH target, rand() AS random_sort",
            "RETURN target.id as ID ORDER BY random_sort LIMIT 1",
        ]
        query = " ".join(entries)
        logger.debug("Neo4j query: %s", query)
        session = driver.session()
        records = session.run(query)
        data = records.single()["ID"]
        session.close()
        return data

    @staticmethod
    def get_random_path(start_id: str, stop_id: str, driver: Neo4jDriver):
        "Get random path from start_id to stop_id screens"
        entries = [
            f'MATCH (start:Screen {{id: "{start_id}"}})',
            f'MATCH (target:Screen {{id: "{stop_id}"}})',
            "MATCH path = (start) - [:GOES_TO|DO_A*0..] - (target:Screen)",
            "RETURN path as PATH",
        ]
        query = " ".join(entries)
        logger.debug("Neo4j query: %s", query)
        session = driver.session()
        records = session.run(query)
        paths = [record["PATH"] for record in records]
        session.close()
        if len(paths) == 0:
            logger.warning(
                "Could not generate path between Screen: %s and Screen: %s",
                start_id,
                stop_id,
            )
            return []
        path = paths[0]
        nodes = path.nodes
        screens = []
        actions = []
        for node in nodes[1:]:
            if "Screen" in node.labels:
                screens.append({"id": node.get("id")})
            if "Click" in node.labels:
                actions.append(
                    {
                        "type": "Click",
                        "locator": decode_base64(node.get("locator")),
                        "id": node.get("id"),
                    }
                )
            if "Fill" in node.labels:
                actions.append(
                    {
                        "type": "Fill",
                        "locator": decode_base64(node.get("locator")),
                        "id": node.get("id"),
                    }
                )
            if "Login" in node.labels:
                actions.append(
                    {
                        "type": "Login",
                        "trigger": decode_base64(node.get("trigger")),
                        "login_user_locator": decode_base64(
                            node.get("login_user_locator")
                        ),
                        "login_password_locator": decode_base64(
                            node.get("login_password_locator")
                        ),
                        "id": node.get("id"),
                    }
                )
        steps = []
        for index, screen in enumerate(screens):
            steps.append({"action": actions[index], "screen": screen})
        return steps

    @staticmethod
    def get_cover_path(project: str, driver: Neo4jDriver):
        "Get random cover path"
        entries = [
            f'MATCH (:Project {{id: "{project}"}})-[:OWNS]->(:StartingScreen)<-[:IS_A]-(ss:Screen)',
            "MATCH (ss)-[*]->(s:Screen)",
            "WHERE NOT (s)<-[:INSTANCE_OF]-(:ScreenInstance)",
            "UNWIND s as list_s",
            "WITH list_s, rand() AS random_sort",
            "RETURN list_s.id AS ID ORDER BY random_sort DESC LIMIT 10",
        ]
        query = " ".join(entries)
        logger.debug("Neo4j query: %s", query)
        session = driver.session()
        records = session.run(query)
        to_be_covered = [record["ID"] for record in records]
        session.close()
        if not to_be_covered:
            steps = []
        else:
            target = random.choice(to_be_covered)
            starting_screen = OneTimeQuery.get_starting_screen(project, driver)
            steps = TargetQuery.get_random_path(
                starting_screen["SCREEN_ID"], target, driver
            )
        logger.debug("Cover mode steps: %s", steps)
        return steps


def create_starting_screen_instance(
    scenario_id: str, screen_id: str, instance_id: str, driver: Neo4jDriver
):
    "Create instance of starting screen."
    logger.debug(
        "Creating ScreenInstance: %s of Screen: %s under Scenario: %s.",
        instance_id,
        screen_id,
        scenario_id,
    )
    query = f"""MATCH (scenario:Scenario {{id: "{scenario_id}"}})
        MATCH (screen:Screen {{id: "{screen_id}"}})
        CREATE (scenario)
            -[:STARTS_AT {{createdAt: datetime()}}]->
        (instance:ScreenInstance {{
                id: "{instance_id}",
                name: "{instance_id}",
                createdAt: datetime()}})
            -[:INSTANCE_OF {{createdAt: datetime()}}]->
        (screen)
    """
    session = driver.session()
    session.run(query)
    session.close()


def add_property(node_id: str, name: str, value: str, driver: Neo4jDriver):
    "Add property to given node."
    logger.debug(
        "Adding property %s of value: %s to node id: %s.",
        name,
        value,
        node_id,
    )
    query = f"""MATCH (node {{id: "{node_id}"}})
        SET node.{name} = "{value}"
    """
    session = driver.session()
    session.run(query)
    session.close()


# def get_uncovered_screen(project_id: str, driver: Neo4jDriver):
#     "Get random uncovered screen."
#     query = f"""MATCH (s:Screen)
#         MATCH (p:Project {{id: "{project_id}"}})
#         WHERE (s)-[*..]-(p) AND NOT (s)-[:INSTANCE_OF]-(:ScreenInstance)
#         UNWIND s AS n
#         WITH n, rand() AS r
#         RETURN n.id as ID ORDER BY r LIMIT 1
#     """
#     logger.debug("Getting random uncovered screen.")
#     session = driver.session()
#     responces = session.run(query)
#     data = [responce["ID"] for responce in responces][0]
#     session.close()
#     return data


# def get_random_screen_only_clicks_not_visited(
#     project_id: str, visited: List[str], driver: Neo4jDriver
# ):
#     "Get random screen filtered by ids in visited and allows only clicks in path."
#     starting_screen = get_starting_screen(project_id, driver)
#     logger.debug("Getting random screen target.")
#     _visited = ", ".join(visited)
#     entries = [
#         f"WITH [{_visited}] as visited",
#         f'MATCH (screen {{id: "{starting_screen["SCREEN_ID"]}"}})',
#         "MATCH path=(screen)-[:GOES_TO|DO_A*0..]-(target:Screen)",
#         'WHERE all(n IN nodes(path) WHERE NOT n.id IN visited AND "Screen" in labels(n) or "Click" in labels(n))',
#         "WITH target, rand() AS random_sort",
#         "RETURN target.id as ID ORDER BY random_sort LIMIT 1",
#     ]
#     query = " ".join(entries)
#     session = driver.session()
#     responces = session.run(query)
#     data = [responce["ID"] for responce in responces][0]
#     session.close()
#     return data


def find_by_id(object_id: str, driver: Neo4jDriver):
    "Find object by id."
    entries = [f'Match (n {{id: "{object_id}"}})', "RETURN n.id as ID"]
    query = " ".join(entries)
    session = driver.session()
    records = session.run(query)
    data = [record["ID"] for record in records]
    if data:
        return True
    return False


def find_by_property(property_key: str, property_value: str, driver: Neo4jDriver):
    "!"
    entries = [f'Match (n: {{{property_key}: "{property_value}"}}', "RETURN n.id as ID"]
    query = " ".join(entries)
    session = driver.session()
    records = session.run(query)
    data = [record["ID"] for record in records]
    if data:
        return data[0]
    return None
