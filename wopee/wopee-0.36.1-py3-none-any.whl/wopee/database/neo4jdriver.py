"Wraper for Neo4j python driver."

import logging
import sys
from uuid import uuid4


from neo4j import GraphDatabase
from neo4j.exceptions import AuthError, ServiceUnavailable

from wopee.config.bot_config import BotConfig
from wopee.database.neo4j.queries import (
    ActionQuery,
    QueryTemplates,
    InstanceQuery,
    TestingQuery,
    OneTimeQuery,
    TargetQuery,
)
from wopee.database.neo4j.queries import (
    find_by_property,
    create_starting_screen_instance,
    add_property,
    find_by_id,
)
from wopee.datatypes.locator import Locator

logger = logging.getLogger(__name__)


class Neo4jDriver:
    "Main class of wrapper for Neo4j python driver."

    def __init__(self, config: BotConfig) -> None:
        logger.debug("Initializing Neo4jDB: Start")
        self.config = config
        self.driver = None
        logger.debug("Initializing Neo4jDB: Done")

    def start(self) -> None:
        "Start Neo4j driver."
        scheme = self.config.neo4j_scheme
        host_name = self.config.neo4j_host_name
        port = self.config.neo4j_port
        user = self.config.neo4j_user
        password = self.config.neo4j_password
        uri = f"{scheme}://{host_name}:{port}"
        logging.debug("Creating Neo4j driver with user: %s at %s.", user, uri)
        self.driver = GraphDatabase.driver(uri, auth=(user, password))
        try:
            session = self.driver.session()
            session.run("RETURN date() AS currentDate")
            session.close()
            logging.debug("Connection to Neo4j is possible.")
        except ServiceUnavailable:
            logger.critical("Neo4j connection error: ServiceUnavailable.")
            sys.exit(1)
        except AuthError:
            logger.critical("Neo4j connection error: AuthError.")
            sys.exit(1)

    def stop(self) -> None:
        "Stop Neo4j driver."
        logger.debug("Closing neo4j driver.")
        self.driver.close()

    def create_click(self, start_id: str, locator: str):
        "Create Click"
        data = {
            "start_id": start_id,
            "click_id": uuid4().hex,
            "locator": locator,
            "screen_id": uuid4().hex,
        }
        ActionQuery.create_click(data, self.driver)

    def create_fill(self, start_id: str, locator: str):
        "Create Fill"
        data = {
            "start_id": start_id,
            "fill_id": uuid4().hex,
            "locator": locator,
            "screen_id": uuid4().hex,
        }
        ActionQuery.create_fill(data, self.driver)

    def create_login(self, start_id: str):
        "Create Login"
        data = {
            "start_id": start_id,
            "login_id": uuid4().hex,
            "trigger": self.config.experimental_login_action["trigger"],
            "login_user_locator": self.config.experimental_login_action[
                "login_user_locator"
            ],
            "login_password_locator": self.config.experimental_login_action[
                "login_password_locator"
            ],
            "login_button": self.config.experimental_login_action["login_button"],
            "screen_id": uuid4().hex,
        }
        ActionQuery.create_login(data, self.driver)

    def create_screen_instance(self, step_id, screen_id):
        "Create ScreenInstance"
        data = {"step_id": step_id, "instance_id": uuid4().hex, "screen_id": screen_id}
        InstanceQuery.create_screen_instance(data, self.driver)
        return data["instance_id"]

    def create_click_instance(self, step_id, click_id, locator):
        "Create ClickInstance"
        data = {
            "step_id": step_id,
            "instance_id": uuid4().hex,
            "locator": locator,
            "click_id": click_id,
        }
        InstanceQuery.create_click_instance(data, self.driver)
        return data["instance_id"]

    def create_fill_instance(self, step_id, click_id, locator, filament):
        "Create FillInstance"
        data = {
            "step_id": step_id,
            "instance_id": uuid4().hex,
            "locator": locator,
            "filament": filament,
            "click_id": click_id,
        }
        InstanceQuery.create_fill_instance(data, self.driver)
        return data["instance_id"]

    def create_login_instance(
        self, step_id, login_id, login_user: str, login_password: str
    ):
        "Create FillInstance"
        data = {
            "step_id": step_id,
            "instance_id": uuid4().hex,
            "login_user": login_user,
            "login_password": login_password,
            "login_id": login_id,
        }
        InstanceQuery.create_login_instance(data, self.driver)
        return data["instance_id"]

    def create_suite(self):
        "Create Suite"
        project_name = self.config.neo4j_project_name
        suite_id = uuid4().hex
        TestingQuery.create_suite(project_name, suite_id, self.driver)
        return suite_id

    def create_scenario(self, suite_id):
        "Create Scenario"
        scenario_id = uuid4().hex
        TestingQuery.create_scenario(suite_id, scenario_id, self.driver)
        return scenario_id

    def create_step(self, start_id: str):
        "Create Step"
        step_id = uuid4().hex
        TestingQuery.create_step(start_id, step_id, self.driver)
        return step_id

    def create_project(self):
        "Create Project"
        project_name = self.config.neo4j_project_name
        if not OneTimeQuery.is_project_existing(project_name, self.driver):
            logger.info(
                "Project %s does not exist. Initializing new one.", project_name
            )
            OneTimeQuery.create_project(project_name, self.driver)
            url = self.config.url
            screen_id = uuid4().hex
            starting_screen_id = uuid4().hex
            OneTimeQuery.create_starting_screen(
                project_name, starting_screen_id, screen_id, url, self.driver
            )

    def get_starting_screen(self):
        "Get starting screen data"
        project_name = self.config.neo4j_project_name
        return OneTimeQuery.get_starting_screen(project_name, self.driver)

    def get_random_screen(self):
        "Get random screen"
        project_name = self.config.neo4j_project_name
        return TargetQuery.get_random_screen(project_name, self.driver)

    def update_graph(self, acceptable_states: list[Locator], current_position):
        "Update graph."
        for acceptable_state in acceptable_states:
            self.create_click(current_position, acceptable_state.base64)

    def update_graph_fill(self, acceptable_states: list[Locator], current_position):
        "Update graph."
        for acceptable_state in acceptable_states:
            self.create_fill(current_position, acceptable_state.base64)

    def get_random_path(self, start_id, stop_id):
        "Get random path."
        return TargetQuery.get_random_path(start_id, stop_id, self.driver)

    def get_cover_path(self, project: str):
        "Get random cover path"
        return TargetQuery.get_cover_path(project, self.driver)

    def create_starting_screen_instance(self, scenario_id, screen_id):
        "Create instance of..."
        instance_id = uuid4().hex
        create_starting_screen_instance(
            scenario_id, screen_id, instance_id, self.driver
        )
        return instance_id

    def add_property(self, node_id: str, name: str, value: str):
        "Add property to given node."
        add_property(node_id, name, value, self.driver)

    def find_by_id(self, object_id):
        "!"
        return find_by_id(object_id, self.driver)

    def find_by_property(self, property_key, property_value):
        "!"
        return find_by_property(property_key, property_value, self.driver)

    def add_label(self, node_id, label):
        "Add label to given node"
        QueryTemplates.add_label(node_id, label, self.driver)
