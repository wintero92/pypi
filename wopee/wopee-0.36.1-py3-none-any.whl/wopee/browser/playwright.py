"Simple Sync Playwright API for bot."

# pylint: disable-msg=no-name-in-module
# pylint: disable-msg=import-error
# pylint: disable-msg=too-many-nested-blocks

import base64
import re
import logging
import os
from typing import List

from playwright.sync_api import (
    TimeoutError as playwrightTimeoutError,
    Page,
    BrowserContext,
    Browser as PlaywrightBrowser,
)
from playwright.sync_api import sync_playwright
from playwright_dompath.dompath_sync import xpath_path

from wopee.browser.browser import Browser
from wopee.config.bot_config import BotConfig
from wopee.datatypes.locator import Locator

logger = logging.getLogger(__name__)


class Playwright(Browser):
    "Sync Playwright wrapper"

    def __init__(self, config: BotConfig) -> None:
        logger.debug("Initializing Browser: Playwright wrapper.")
        self.config: BotConfig = config
        self.playwright = None
        self.browser: PlaywrightBrowser = None
        self.context: BrowserContext = None
        self.page: Page = None
        self.device = None
        logger.debug("Done initializing Browser: Playwright wrapper.")

    def start(self):
        self.playwright = sync_playwright().start()
        self.device = {
            "viewport": {"width": 1920, "height": 1080},
            "is_mobile": False,
            "has_touch": False,
            "ignore_https_errors": self.config.ignore_https_errors,
        }
        if self.config.save_video:
            self.device["record_video_dir"] = "videos/"
            self.device["record_video_size"] = {"width": 640, "height": 360}
        self.browser = self.playwright.chromium.launch(headless=self.config.headless)
        logger.debug("Playwright initialization done")

    def start_context(self):
        "Start new context"
        self.context = self.browser.new_context(**self.device)
        self.context.set_default_navigation_timeout(self.config.navigation_timeout)
        self.context.tracing.start(screenshots=True, snapshots=True, sources=False)
        self.page = self.context.new_page()
        result = self.goto(self.config.url)
        if not result:
            return False
        self.accept_cookies()
        return True

    def close_context(self, scenario_id: str):
        "Stop current context"
        if self.config.save_video:
            video_path = self.page.video.path()
            extension = video_path.split(".")[-1]
            folder = "/".join(video_path.split("/")[0:-1])
            try:
                os.replace(video_path, f"{folder}/{scenario_id}.{extension}")
            except:
                pass
        if self.config.save_trace:
            self.context.tracing.stop(path=f"trace_{scenario_id}.zip")
        else:
            self.context.tracing.stop()
        self.context.close()

    def stop(self):
        self.browser.close()
        logger.debug("Playwright stopped")

    def goto(self, url: str) -> None:
        "Goto url"
        logger.debug("Going to %s", url)
        try:
            self.page.goto(url)
            self.page.wait_for_load_state("load")
            return True
        except playwrightTimeoutError:
            logger.debug("Unable to access url: %s", url)
            return False

    def click(self, locator) -> bool:
        try:
            self.page.click(locator)
            logger.debug("Action: click on locator: %s was succesful.", locator)
            return True
        except playwrightTimeoutError:
            logger.debug("Action: click on locator: %s failed.", locator)
            return False

    def scroll_down(self, delta_y=1000):
        "Load lazy-loaded page via scrolling down and back up"
        logger.debug("Scrolling page to load lazy content")
        curr_height = self.page.evaluate("(window.innerHeight + window.scrollY)")
        logger.debug("Current height: %s", curr_height)
        new_height = 0
        max_scroll_downs = 50
        n_scroll_downs = 0
        while (curr_height - new_height) != 0:
            n_scroll_downs += 1
            curr_height = new_height
            self.page.mouse.wheel(0, delta_y)
            self.page.wait_for_load_state("load")
            new_height = self.page.evaluate("(window.innerHeight + window.scrollY)")
            logger.debug("Current height: %s", new_height)
            if n_scroll_downs > max_scroll_downs:
                logger.debug(
                    "Reached limit for scroll downs %s x %s", max_scroll_downs, delta_y
                )
                break
        self.page.wait_for_load_state("load")
        self.page.wait_for_timeout(self.config.time_out)
        return self.page.evaluate("(window.innerHeight + window.scrollY)")

    def after_action(self) -> None:
        "After action action."
        self.page.on("dialog", lambda dialog: dialog.accept())

    def check(self, locator) -> None:
        self.page.check(locator)

    def dblclick(self, locator) -> None:
        self.page.dblclick(locator)

    def drag_and_drop(self, source, target) -> None:
        self.page.drag_and_drop(source, target)

    def fill(self, locator, filament) -> None:
        self.page.fill(locator, filament)

    def focus(self, locator) -> None:
        self.page.focus(locator)

    def hover(self, locator) -> bool:
        try:
            self.page.hover(locator)
            logger.debug("Action: hover on locator: %s was succesful.", locator)
            return True
        except playwrightTimeoutError:
            logger.debug("Action: hover on locator: %s failed.", locator)
            return False

    def wait_for_element(self, locator):
        "Wait for element"
        logger.debug("Waiting for fixed time: %s", self.config.time_out)
        self.page.wait_for_timeout(self.config.time_out)
        element = self.page.locator(locator)
        try:
            element.wait_for(timeout=self.config.navigation_timeout, state="visible")
            logger.debug("Locator: %s founded", locator)
        except playwrightTimeoutError:
            logger.debug(
                "Element %s was not visible after %s ms",
                locator,
                self.config.navigation_timeout,
            )

    def screenshot(self, height, selector) -> str:
        "Create screenshot"
        self.page.set_viewport_size({"width": 1920, "height": int(height)})
        self.page.wait_for_load_state("load", timeout=self.config.navigation_timeout)
        logger.debug("Done: load event")
        self.page.wait_for_timeout(self.config.after_load_screenshot_timeout)
        logger.debug(
            "Fixed time wait for %s", self.config.after_load_screenshot_timeout
        )
        try:
            self.hover(selector)
        except:
            pass
        full_page_image = self.page.screenshot(full_page=True)
        full_page_image_base64 = base64.b64encode(full_page_image).decode("utf-8")
        logger.debug("Full page screenshot created")
        self.page.set_viewport_size({"width": 1920, "height": 1080})
        return full_page_image_base64

    def type(self, locator, filament) -> None:
        self.page.type(locator, filament)

    def accept_cookies(self):
        "Accept cookies."
        cookies_selector = self.config.cookies_selector
        if cookies_selector is not None:
            if isinstance(cookies_selector, List):
                logger.debug("Multi-click cookies acceptance...")
                self.page.click((cookies_selector[0]))
                logger.debug("Multi-click cookies acceptance: Click 1.")
                for i in range(1, len(cookies_selector)):
                    try:
                        self.page.click(
                            (cookies_selector[i]), timeout=self.config.time_out * 5
                        )
                        logger.debug("Multi-click cookies acceptance: Click %s.", i + 1)
                    except playwrightTimeoutError:
                        logger.warning(
                            "Falied to click on %sth click of multi-click cookies acceptence. Continue with testing...",
                            i + 1,
                        )
            else:
                try:
                    self.page.click(self.config.cookies_selector)
                except playwrightTimeoutError:
                    logger.warning("Unable to click on cookies.")
            logger.debug("Cookies accepted.")

    def check_domain(self):
        "Check if bot is leaving set of allowed url."
        current_url = self.page.url
        tested_url = self.config.url.replace("http://", "").replace("https://", "")
        allowed_urls = [
            url.replace("http://", "").replace("https://", "")
            for url in self.config.allowed_urls
        ]
        allowed_urls.append(tested_url)
        for allowed_url in allowed_urls:
            match = re.search(allowed_url, current_url)
            if match:
                return True
        logger.debug("Random interaction left tested domains.")
        return False

    def eval_ignored_areas(self):
        "Get ignore areas."
        ignored_locators = self.config.ignored_areas_by_locator
        locator_images = []
        for locator in ignored_locators:
            element = self.page.locator(locator)
            if element.is_visible():
                element_image = element.screenshot()
                locator_images.append(element_image)
        return locator_images

    def collect_all_ignored_elements(self) -> list[str]:
        "Collect full xpaths of all ignored locators"
        ignored_xpaths = []
        for locator in self.config.ignored_locators:
            elements = self.page.locator(locator)
            n_elements = elements.count()
            for i in range(n_elements):
                try:
                    element = elements.nth(i)
                    xpath = xpath_path(element, optimized=False)
                except:
                    continue
                ignored_xpaths.append(xpath)
        return ignored_xpaths

    def check_if_ignored(self, locator):
        "Check if given locator falls down into ignored"
        element = self.page.locator(locator)
        try:
            xpath = xpath_path(element, optimized=False)
            for ignored_element in self.collect_all_ignored_elements():
                if xpath in ignored_element:
                    return True
            return False
        except:
            return False

    def collect_all_acceptable_states(self) -> list[Locator]:
        "Collect all visible and enabled locators."
        tag_selectors = self.config.tags
        acceptable_states = []
        for tag_selector in tag_selectors:
            elements = self.page.locator(tag_selector)
            n_elements = elements.count()
            for i in range(n_elements):
                try:
                    element = elements.nth(i)
                    element_xpath = xpath_path(element, optimized=False)
                except:
                    continue
                if element_xpath in self.collect_all_ignored_elements():
                    continue
                try:
                    if element.is_visible():
                        if element.is_enabled():
                            locator = self._get_locator(element, tag_selector)
                            if self.page.locator(locator).count() == 1:
                                acceptable_states.append(Locator(raw_string=locator))
                except:  # pylint: disable-msg=bare-except
                    logger.exception("Skipping locator due to issue with DOM.")
        return acceptable_states

    def collect_acceptable_inputs(self) -> list[Locator]:
        "Collect all visible inputs."
        acceptable_states = []
        elements = self.page.locator("//input")
        n_elements = elements.count()
        for i in range(n_elements):
            try:
                element = elements.nth(i)
            except:
                continue
            try:
                if (
                    element.is_visible()
                    and element.is_enabled()
                    and element.is_editable()
                ):
                    locator = self._get_locator(element, "input")
                    if self.page.locator(locator).count() == 1:
                        acceptable_states.append(Locator(raw_string=locator))
            except:  # pylint: disable-msg=bare-except
                logger.exception("Skipping input locator due to issue with DOM.")
        return acceptable_states

    def collect_acceptable_logins(self):
        "Collect all visible logins."
        elements = self.page.locator(self.config.experimental_login_action["trigger"])
        n_elements = elements.count()
        if n_elements != 1:
            logger.warning("Trigger for login action is not unique.")
        try:
            if elements.nth(0).is_visible():
                logger.debug("Login action trigger founded.")
                return True
        except:  # pylint: disable-msg=bare-except
            logger.exception("Skipping input locator due to issue with DOM.")
        return False

    def _get_locator(self, element, element_tag):
        "Get locator of the element."
        parent = element.locator("xpath=..")
        parent_class = self._get_class_formatted(parent)
        element_text = self._get_text_formatted(element)
        element_class = self._get_class_formatted(element, element_tag=element_tag)
        locator = parent_class + " >> " + element_class
        if element_text is not None:
            locator += " >> text=" + element_text
        return locator

    @staticmethod
    def _get_text_formatted(element):
        "Get formatted text of the element."
        raw_text = element.inner_text()
        if raw_text == "":
            return None
        if len(raw_text.split()) == 1:
            return raw_text
        regex_text = raw_text
        return regex_text

    @staticmethod
    def _get_class_formatted(element, element_tag="*"):
        "Get formatted class of the element."
        raw_class = element.get_attribute("class")
        xpath = "xpath=//" + element_tag
        if raw_class is not None and raw_class != "":
            xpath += "[@class='" + raw_class + "']"
        return xpath

    def url(self):
        return self.page.url

    def page_title(self) -> str:
        return self.page.title()
