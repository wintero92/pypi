"Template for browser driver"

from abc import abstractmethod


class Browser:
    "Abstract browser driver class"

    @abstractmethod
    def start(self) -> None:
        "Init browser"

    @abstractmethod
    def start_context(self) -> None:
        "Init context"

    @abstractmethod
    def close_context(self, scenario_id: str) -> None:
        "Close context"

    @abstractmethod
    def stop(self) -> None:
        "Stop browser"

    @abstractmethod
    def check(self, locator) -> None:
        "Check interaction with element given by locator"

    @abstractmethod
    def click(self, locator) -> None:
        "Click interaction with element given by locator"

    @abstractmethod
    def dblclick(self, locator) -> None:
        "Double click interaction with element given by locator"

    @abstractmethod
    def drag_and_drop(self, source, target) -> None:
        "Drag and drop interaction with given source and target"

    @abstractmethod
    def fill(self, locator, filament) -> None:
        "Fill interaction on element with given locator and filament"

    @abstractmethod
    def focus(self, locator) -> None:
        "Focus interaction on element with given locator"

    @abstractmethod
    def hover(self, locator) -> None:
        "Hover interaction on element with given locator"

    @abstractmethod
    def screenshot(self, height, selector) -> str:
        "Take screenshot of full page"

    @abstractmethod
    def type(self, locator, filament) -> None:
        "Type interaction on element with given locator and filament"

    @abstractmethod
    def page_title(self) -> str:
        "Returns title of current page"

    @abstractmethod
    def url(self) -> str:
        "Returns url of  current page"
