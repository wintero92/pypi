"Simple VRT api for bot"


import logging
import sys
from typing import List

from visual_regression_tracker import Config as VrtConfig
from visual_regression_tracker import (
    IgnoreArea,
    ServerError,
    TestRun,
    VisualRegressionTracker,
)

from wopee.config.bot_config import BotConfig
from wopee.tracker.tracker import Tracker

logger = logging.getLogger(__name__)


class Vrt(Tracker):
    "Tracking implementation via VRT."

    def __init__(self, config: BotConfig):
        self.config = config
        self.driver = None

    def start(self) -> None:
        vrt_config = VrtConfig(
            apiUrl=self.config.vrt_api_url,
            project=self.config.vrt_project_name,
            apiKey=self.config.vrt_api_key,
            ciBuildId=self.config.vrt_ci_build_id,
            branchName=self.config.vrt_branch_name,
            enableSoftAssert=True,
        )
        self.driver = VisualRegressionTracker(vrt_config)
        try:
            self.driver.start()
        except ServerError as error:
            if "Unauthorized" in str(error):
                logger.critical("VRT: Unauthorized")
            elif "Api key not authenticated" in str(error):
                logger.critical("VTR: Api key not authenticated")
            elif "Project not found" in str(error):
                logger.critical("VRT: Project not found: %s", vrt_config.project)
            else:
                logger.critical("VRT: Unspecified error during connection.")
            sys.exit(1)
        logger.debug("Connected to VRT.")

    def stop(self) -> None:
        try:
            self.driver.stop()
        except:
            pass

    def screenshot(self, state_id, screenshot, ignore_areas: List[IgnoreArea] = None):
        result = None
        try:
            result = self.driver.track(
                TestRun(
                    name=state_id,
                    imageBase64=screenshot,
                    diffTollerancePercent=self.config.vrt_diff_tollerance,
                    ignoreAreas=ignore_areas,
                )
            )
            logger.debug("Screenshot under id: %s uploaded to VRT.", state_id)
        except:
            logger.exception("VRT undefined problem:", exc_info=True)
        return result
