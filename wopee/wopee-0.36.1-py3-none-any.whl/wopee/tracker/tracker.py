"Abstract class for tracking related stuff."


from abc import abstractmethod


class Tracker:
    "Abstract tracking class."

    @abstractmethod
    def start(self) -> None:
        "Abstract method taking care of connection to tracking service."

    @abstractmethod
    def stop(self) -> None:
        "Abstract method taking care of disconnection to tracking service."

    @abstractmethod
    def screenshot(self, state_id, screenshot, ignore_areas):
        "Abstract method taking care of tracking screenshot."
