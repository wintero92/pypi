"""Collection of Helper functions."""

import base64


def decode_base64(base64_string: str):
    """Decode base64 string to raw string."""
    base64_bytes = base64_string.encode("utf-8")
    locator_bytes = base64.b64decode(base64_bytes)
    locator = locator_bytes.decode("utf-8")
    return locator


def encode_base64(raw_string: str):
    """Encode raw string to base64 string."""
    locator_bytes = raw_string.encode("utf-8")
    base64_bytes = base64.b64encode(locator_bytes)
    base64_locator = base64_bytes.decode("utf-8")
    return base64_locator
