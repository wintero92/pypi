"""Locator datatype."""

# pylint: disable=too-few-public-methods

from wopee.datatypes.helper import decode_base64, encode_base64


class Locator:
    """Locator datatype class."""

    def __init__(self, base64=None, raw_string=None):
        if base64 is not None and raw_string is not None:
            raise ValueError("Cannot specify both base64 and raw_string.")
        if base64 is not None:
            self.base64 = base64
            self.raw_string = decode_base64(base64)
        elif raw_string is not None:
            self.raw_string = raw_string
            self.base64 = encode_base64(raw_string)
